
import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtNumber: UILabel!
    @IBOutlet weak var fecha: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        GenerateDate()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func GenerateDate() {
        let format = DateFormatter()
        format.dateFormat = "dd/MM/yyyy HH:mm:ss"
        let fec = format.string(from: NSDate() as Date)
        fecha.text = "\(fec)"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func seedAction(_ sender: Any) {
        srandom(CUnsignedInt(time(nil)))
        txtNumber.text = "Generator seeder"
    }
    
    @IBAction func generateAction(_ sender: Any) {
        let generated = (arc4random() % 100)+1
        txtNumber.text = "\(generated)"
        GenerateDate()
    }
}

