
import UIKit

var	monto = 100

print("1- Pepsi $90")
print("2- CocaCola $90")
print("3- Juguito $80")
print("4- Agua $70")
print("")

var bebida = 3

if(bebida == 1 || bebida == 2){
    if(monto == 90){
        print("Bebida cae")
    }
    else if(monto > 90){
        print("Bebida cae y su vuelto es: $\(monto-90)")
    }
    else{
        print("Ingrese mas dinero... o elija otra bebida")
    }
}

if(bebida == 3){
    if(monto == 80){
        print("Agua cae")
    }
    else if(monto > 80){
        print("Agua cae y su vuelto es: $\(monto-80)")
    }
    else{
        print("Ingrese mas dinero... o elija otra bebida")
    }
}

if(bebida == 4){
    if(monto == 70){
        print("Bebida cae")
    }
    else if(monto > 70){
        print("Bebida cae y su vuelto es: $\(monto-70)")
    }
    else{
        print("Ingrese mas dinero... o elija otra bebida")
    }
}
