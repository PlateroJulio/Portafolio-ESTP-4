import UIKit
import CoreData

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var managedObjetContext: NSManagedObjectContext!
    @IBOutlet weak var myTableView: UITableView!
    @IBOutlet weak var txtBookName: UITextField!
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return loadBooks().count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") else{ return UITableViewCell()}
        let book: Book = loadBooks()[indexPath.row]
        cell.textLabel?.text = book.title
        return cell
    }
    
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCellEditingStyle {
        return .delete
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            tableView.beginUpdates()
            
            tableView.deleteRows(at: [indexPath], with: .fade)
            myTableView.reloadData()
            tableView.endUpdates()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let appDelegate: AppDelegate = UIApplication.shared.delegate as! AppDelegate
        managedObjetContext = appDelegate.persistentContainer.viewContext as NSManagedObjectContext
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func loadBooks() -> [Book] {
        let fetchRequest: NSFetchRequest<Book> = Book.fetchRequest()
        var result: [Book] = []
        do {
            result = try managedObjetContext.fetch(fetchRequest)
        }catch{
            NSLog("My Error: %@", error as NSError)
        }
        return result
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func addNew(_ sender: Any) {
        let book: Book = NSEntityDescription.insertNewObject(forEntityName: "Book", into: managedObjetContext) as! Book
        book.title = "My Book" + String(loadBooks().count)
        do {
            try managedObjetContext.save()
        }catch{
            NSLog("My Error: %@", error as NSError)
        }
        myTableView.reloadData()
    }
    @IBAction func AddBook(_ sender: UIButton) {
        let book: Book = NSEntityDescription.insertNewObject(forEntityName: "Book", into: managedObjetContext) as! Book
        book.title = txtBookName.text
        do {
            try managedObjetContext.save()
        }catch{
            NSLog("My Error: %@", error as NSError)
        }
        txtBookName.text = ""
        myTableView.reloadData()
        
    }
    

}

