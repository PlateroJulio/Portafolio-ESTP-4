//: Playground - noun: a place where people can play

import UIKit

var num1 = 10.2
var num2 = 3.4

print("resultado = \(Int(num1 - num2))")
