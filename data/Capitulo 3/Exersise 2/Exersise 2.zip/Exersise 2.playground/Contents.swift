//: Playground - noun: a place where people can play

import UIKit

var decimal = 10.4

var cuadre = 4.0

var resultado = 0.0

resultado = decimal * cuadre

print("decimal al cuadrado =  \(resultado)")
