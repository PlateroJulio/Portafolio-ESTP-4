//: Playground - noun: a place where people can play

import UIKit

var num1 = 2
var num2 = 4

var result = 0

result = num1 * num2
print("resultado = \(result)")
