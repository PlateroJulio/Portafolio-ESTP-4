//
//  BookStore.swift
//  BookStore
//
//  Created by Development on 11/24/21.
//  Copyright © 2021 Development. All rights reserved.
//

import Foundation

class BookStore{
    var bookList: [Book] = []
    
    init() {
        fillList()
    }
    
    func fillList(){
        var newBook = Book()
        newBook.title = "Swift for Absolute Beginners"
        newBook.author = "Bennett and Lees"
        newBook.description = "IOS Programming made easy."
        newBook.price = "$50.00"
        bookList.append(newBook)
        
        newBook = Book()
        newBook.title = "A Farewell to Arms"
        newBook.author = "Ernest Hemingway"
        newBook.description = "The story of an affair between an English nurs and an American soldier on the Italian front during World War I"
        newBook.price = "$20.00"
        bookList.append(newBook)
        
        newBook = Book()
        newBook.title = "The Adventures of Tom Sawyer"
        newBook.author = "Mark Twain"
        newBook.description = "The adventures of Tom Sawyer, through the eyes of his characters, Mark Twain offers us a vision of a double reality: that of the infantile, primitive world, which the adult reader has already lost..."
        newBook.price = "$15.00"
        bookList.append(newBook)
        
        newBook = Book()
        newBook.title = "To Kill a Mockingbird"
        newBook.author = "Harper Lee"
        newBook.description = "This enhanced digital edition of Harper Lee's Pulitzer prize-winning masterwork of honor and injustice in the deep south includes audio of Sissy Spacek performing the audiobook and video footage from the documentary"
        newBook.price = "$33.00"
        bookList.append(newBook)
    }
}
