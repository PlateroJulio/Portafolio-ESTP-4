import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var stationName: UILabel!
    @IBOutlet weak var stationFrequency: UILabel!
    @IBOutlet weak var stationBand: UILabel!
    
    var myStation : RadioStation
    
    required init?(coder aDecoder: NSCoder) {
        myStation = RadioStation()
        myStation.frequency = 104.7
        myStation.name = "KZZP"
        super.init(coder: aDecoder)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func buttonClick(_ sender: UIButton) {
        stationName.text = self.myStation.name
        stationFrequency.text = "\(myStation.frequency)"
        if(myStation.isBandFM() == 1){
            stationBand.text = "FM"
        }else{
            stationBand.text = "AM"
        }
        if(myStation.frequency > 520.0 ){
            stationBand.text = "FM"
            myStation.frequency = 104.7
            myStation.name = "YSKU"
            stationName.text = self.myStation.name
            stationFrequency.text = "\(myStation.frequency)"        }
    }
    @IBAction func changed(_ sender: UIButton) {
        
        if(myStation.frequency < 520.0 ){
            stationBand.text = "AM"
            myStation.frequency = 604.7
            myStation.name = "KZZP"
            stationName.text = self.myStation.name
            stationFrequency.text = "\(myStation.frequency)"         }
    }
    
    
}

