//
//  RadioStation.swift
//  RadioStations
//
//  Created by Development on 11/6/21.
//  Copyright © 2021 Development. All rights reserved.
//

import UIKit

class RadioStation: NSObject {
    var name: String
    var frequency: Double
    
    override init() {
        name = "Default"
        frequency = 100.0
    }
    
    static var minAMFrequency: Double = 520.00
    static var maxAMFrequency: Double = 1610.0
    static var minFMFrequency: Double = 88.30
    static var maxFMFrequency: Double = 107.9
    
    func isBandFM() -> Int {
        if(frequency >= RadioStation.minFMFrequency && frequency <= RadioStation.maxFMFrequency){
            return 1 //FM
        }else{
            return 0 //AM
        }
    }
    
    
    
}
