//: Playground - noun: a place where people can play

import UIKit

var  years  =  [1800, 1801, 1900, 2000, 2001, 2003, 2010]

for year in years {
    if((year %  4 == 0 && year % 100 != 0) || (year %  100 == 0 && year % 400 == 0) ){
        print("El year \(year) si es bisiesto")
    }else {
        print("El year \(year) no es bisiesto")
    }
}
