	//
//  ViewController.swift
//  Chapter6
//
//  Created by Development on 10/23/21.
//  Copyright © 2021 Development. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBAction func showName(sender: AnyObject){
        nameLabel.text = "My name is Julio!"
    }
    
    @IBAction func changedName(sender: AnyObject){
        nameLabel.text = "Your name changed is Vladimir!"
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

