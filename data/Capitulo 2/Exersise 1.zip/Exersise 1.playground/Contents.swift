//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
print(str)

var mensaje = "Mi nombre es Julio Platero!"
print(mensaje)
