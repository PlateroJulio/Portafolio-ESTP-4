//
//  Autor.swift
//  BookStore
//
//  Created by Development on 9/18/21.
//  Copyright © 2021 Development. All rights reserved.
//

import UIKit

class Autor: NSObject {
    var firstName = ""
    var lastName = ""
    
}
