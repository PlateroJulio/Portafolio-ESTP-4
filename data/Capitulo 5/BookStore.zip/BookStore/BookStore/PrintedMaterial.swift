//
//  PrintedMaterial.swift
//  BookStore
//
//  Created by Development on 9/18/21.
//  Copyright © 2021 Development. All rights reserved.
//

import UIKit

class PrintedMaterial: NSObject {
    var Title = ""
    var PunlishDate = ""
    var PageCount = ""
    var Price = ""
    var Publisher = ""
    
    func Message() {
        return print("Message from Father...")
    }
}
