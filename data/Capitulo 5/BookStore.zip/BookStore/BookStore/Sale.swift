//
//  Sale.swift
//  BookStore
//
//  Created by Development on 9/24/21.
//  Copyright © 2021 Development. All rights reserved.
//

import UIKit

class Sale: NSObject {
    var objCustomer:Customer=Customer()
    var objBook:Book=Book()
    var date = ""
    var time = ""
    var amount = ""
    var paymentType = ""
    
    func chargeCreditCard(creditCard:String){
        print("\(creditCard)")
    }
    
    func printInvoice(){
        print("****** Invoice ******")
    }
    
    func checkout(){
        print("your checking ...")
    }
}
