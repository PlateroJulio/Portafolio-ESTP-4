//
//  Bookstore.swift
//  BookStore
//
//  Created by Development on 9/24/21.
//  Copyright © 2021 Development. All rights reserved.
//

import UIKit

class Bookstore: NSObject {
    var name = ""
    var addressLine1 = ""
    var addressLine2 = ""
    var city = ""
    var state = ""
    var zip = ""
    var phoneNumber = ""
    var logo = ""
}
