	//
//  Customer.swift
//  BookStore
//
//  Created by Development on 9/18/21.
//  Copyright © 2021 Development. All rights reserved.	
//

import UIKit

class Customer: NSObject {
    var firstName = ""
    var lastName = ""
    var addressLine1 = ""
    var addressLine2 = ""
    var city = ""
    var state = ""
    var zip = ""
    var phoneNumber = ""
    var emailAddress = ""
    var favoriteGenre = ""
    
    
    func ListPurchaseHistory() -> [String] {
        return ["Purchase 1","Purchase 2"]
    }
}
